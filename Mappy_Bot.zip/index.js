const Discord = require('discord.js');
const client = new Discord.Client();
client.once('ready', () => {console.log('Ready!');});
client.login('NzczODYxODAzMjUxNzI4NDI1.X6PY9w.zPzhXHl_DNTP23RrOoa_BFcY0m0');